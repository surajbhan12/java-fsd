package com.Product;



import java.util.List;
import java.util.Scanner;

import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class ProductMain {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		Product p=new Product();
		while(true) {
		System.out.println("1. Insert\n2. View\n3. Exit");
		System.out.println("Choose Option :>");
		int x=sc.nextInt();
		switch(x) {
			case 1: StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
			        Metadata md=new MetadataSources(ssr).getMetadataBuilder().build();
			        SessionFactory sf=md.getSessionFactoryBuilder().build();	
			        Session s=sf.openSession();
			        Transaction t=s.beginTransaction();
			        System.out.println("Enter Product id :>");
				    p.setPid(sc.nextInt());
				    System.out.println("Enter Product Name :>");
				    p.setPname(sc.next());
				    System.out.println("Enter Product Price :>");
				    p.setPrice(sc.nextDouble());
				//insert
				    s.save(p);
				    t.commit();
				    s.close();
					sf.close();
				    
			break;
			case 2: StandardServiceRegistry ssr1=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
	        		Metadata md1=new MetadataSources(ssr1).getMetadataBuilder().build();
	        		SessionFactory sf1=md1.getSessionFactoryBuilder().build();	
	        		Session s1=sf1.openSession();
				//select * from Product;
	        		Query q=s1.createQuery("from Product");
	        		List<Product> pro =q.list();
	        		for(Product dis:pro) {
					System.out.println(dis.getPid()+" "+dis.getPname()+" "+dis.getPrice());
	        		}
	        		s1.close();
	        		sf1.close();
			break;
			case 3:System.exit(0);
			break;
			default : System.out.println("Choose Right Option !");
			break;
		}
		}
		
		}

}
