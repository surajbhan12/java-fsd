package com.example;

import static org.junit.Assert.*;

import javax.servlet.http.HttpServletRequest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AuthenticationTest {
	Authentication du;
	@Before
	public void objectcreate() {
		du=new Authentication();
		System.out.println("object created");
	}

	@Test
	public void test1() {
		System.out.println("test case 1");
		assertEquals("Login Successfully", du.Authenticate("user", "pass"));
	}
	@Test
	public void test2() {
		System.out.println("test case 2");
		assertEquals("Login failed",du.Authenticate("use", "pass"));
	}
	@Test
	public void test3() {
		System.out.println("test case 3");
		assertEquals("Login failed", du.Authenticate("user", "pas"));
	}
	@Test
	public void test4() {
		System.out.println("test case 4");
		assertEquals("Login failed", du.Authenticate("use", "pas"));
	}
	@After
	public void objectremove() {
		du=null;
		System.out.println("object is removed");
	}

}
