package com.example;

public class Authentication {
	public String Authenticate(String username,String password) {
		if(username.equals("user") && password.equals("pass")) {
			return "Login Successfully";
		}else {
			return "Login failed";
		}
			
	}
}
