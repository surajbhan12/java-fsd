package Array;
import java.util.*;
public class SumOf_N_Number {

	public static void main(String[] args) {
		int arr[]= {9,3,6,2,33,42,55,7,4};
		Scanner sc=new Scanner(System.in);
		int l,r,sum=0;
		System.out.println("Enter the left side index value :-");
		l=sc.nextInt();
		if(l<0 || l>arr.length-1) {
			System.out.println("left index value is incorrect !");
			System.exit(0);
		}
		System.out.println("Enter right side index value :- ");
		r=sc.nextInt();
		if(r<l || r>arr.length-1) {
			System.out.println("Right side index value is incorrect !");
			System.exit(0);
		}
		for(int i=l;i<=r;i++) {
			sum=sum+arr[i];
		}
		System.out.println("Sum of n numbers is "+sum);

	}
}
