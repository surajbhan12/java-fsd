package Array;
import java.util.*;
public class ArrayRotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {9,4,7,3,1,8,5};
		int i,n=5,temp,j=arr.length,d=0;
		while(d<n) {
			temp=arr[0];
			for(i=0;i<j-1;i++)
			{
				arr[i]=arr[i+1];
			}
			arr[j-1]=temp;
			d++;
		}
		System.out.println("After rotation :>");
		for(int z:arr) {
			System.out.println(z);
		}
	}

}
