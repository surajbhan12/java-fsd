package StackAndQueue;

import java.util.Scanner;

public class QueueEnqueueDequeue {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of Queue :-");
		int n=sc.nextInt();
        int Queue[]=new int[n];
        int f=-1,r=-1,c;
        System.out.println("Queue Operations");
        while(true) {
        	System.out.println("Enter Choice :- 1.Enqueue  2.Dequeue  3.Display   4.Exit");
        	c=sc.nextInt();
        	switch(c) {
        	case 1:if(r==n-1) {
				System.out.println("Q is full no more insertions");
			}
			else {
				System.out.println("enter the ele to insert");
				int key=sc.nextInt();
				r++;
				Queue[r]=key;
				f=0;
			}
			break;
			
			case 2:if((f==-1&&r==-1)||(f>r)) {
				System.out.println("Q is empty no del operation");
				f=-1;
				r=-1;
			}
			else {
				f=f+1;
			}
			break;
			case 3:if((f==-1&&r==-1)||(f>r)) {
				System.out.println("Q is empty ");
			}
			else {
				for(int i=f;i<=r;i++) {
					System.out.println(Queue[i]);
				}
			}
			break;
			case 4:System.exit(0);
			break;
			default:System.out.println("check ur choice");
			break;	

        	}
        }
	}

}
