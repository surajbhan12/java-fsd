package Array;
import java.util.*;
public class ForthSmallest {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {9,4,7,3,1,8,5};
		Arrays.sort(arr);
		System.out.println("the forth smallest number is :> "+arr[3]);
	}

}
