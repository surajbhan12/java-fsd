package LinkedList;

import LinkedList.SinglyLL.Node;
public class CircularLL {
	class Node{
		int data;
		Node next;
		public Node(int data) {
			this.data=data;
			
		}
	}
	public Node head=null;
	public Node tail=null;
	public void addNode(int data) {
		Node newNode=new Node(data);
		if(head==null) {
			head=newNode;
			tail=newNode;
			newNode.next=head;
		}
		else {
			tail.next=newNode;
			tail=newNode;
			tail.next=head;
		}
	}
	public void display() {
		Node current=head;
		if(head==null) {
			System.out.println("List is empty !");
		}
		else {
			System.out.println("Nodes of circular linked list are :-");
			do{
				System.out.print(current.data+" ");
				current=current.next;
			}while(current!=head);
			System.out.println();
		}
	}
	public void sort() {
		Node current=head;
		Node temp=null;
		int value;
		if(head==null){
			System.out.println("List is Empty !");
		}else {
				while(current.next!=head) {
					temp=current.next;
					while(temp!=head) {
						if(current.data>temp.data) {
							value=current.data;
							current.data=temp.data;
							temp.data=value;
						}
						temp=temp.next;
					}
					current=current.next;
				}
			}
	}
	public static void main(String[] args) {
	    CircularLL cl=new CircularLL();
		cl.addNode(6);
		cl.addNode(4);
		cl.addNode(9);
		cl.addNode(1);
		cl.addNode(2);
		cl.display();
		cl.sort();
		cl.display();
		
	}
}
