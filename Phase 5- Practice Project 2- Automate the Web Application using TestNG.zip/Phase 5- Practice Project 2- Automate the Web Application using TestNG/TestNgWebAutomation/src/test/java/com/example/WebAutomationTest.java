package com.example;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class WebAutomationTest {
	
	WebDriver wd;

	
  @Test
  public void test() throws InterruptedException {
		wd.get("http://localhost:8083/");
		wd.findElement(By.name("email")).sendKeys("mani@123");
		wd.findElement(By.name("pwd")).sendKeys("mani@123");
		Thread.sleep(2000);
		wd.findElement(By.name("submit")).click();
		Thread.sleep(2000);
		wd.findElement(By.linkText("register here...")).click();
		wd.findElement(By.name("name")).sendKeys("manish");
		wd.findElement(By.name("email")).sendKeys("mani@123");
		wd.findElement(By.name("pwd")).sendKeys("mani@123");
		Thread.sleep(2000);
		wd.findElement(By.name("submit")).click();
		wd.findElement(By.name("email")).sendKeys("mani@123");
		wd.findElement(By.name("pwd")).sendKeys("mani@123");
		Thread.sleep(2000);
		wd.findElement(By.name("submit")).click();
		Thread.sleep(2000);


	  
  }
  @BeforeTest
  public void beforeTest() {
	  WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();

  }

  @AfterTest
  public void afterTest() {
	  wd.quit();

  }

}
