package com.example;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {

	@Autowired
	UserRepo repo;
	Logger log=Logger.getAnonymousLogger();
	
	@RequestMapping("/")
	public ModelAndView loadpage(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("login.html");
		log.info("login page loaded ");
		return mv;
		
	}
	
	
	@RequestMapping("/login")
	public ModelAndView checklogin(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		String email= request.getParameter("email");
		if((repo.findByemail(email)!=null)&&(repo.findBypassword(request.getParameter("pwd"))!=null)) {
		if(repo.findByemail(email).equals(repo.findBypassword(request.getParameter("pwd"))))
		{
			mv.setViewName("display.html");
		}
		}
		else {
			mv.setViewName("fail.jsp");
		}
		
		return mv;
		
	}
	@RequestMapping("/register")
	public ModelAndView registerms(HttpServletRequest request,HttpServletResponse response) {
		User u=new User();
		ModelAndView mv=new ModelAndView();
		u.setUsername(request.getParameter("name"));
		u.setPassword(request.getParameter("pwd"));
		u.setEmail(request.getParameter("email"));
		repo.save(u);
		mv.setViewName("login.html");
		return mv;
		
	}
	
}

