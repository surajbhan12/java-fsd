package Threads;

public class Thread2 extends Thread {
	public void run() {
		for(int j=0;j<=10;j++)
		{
			System.out.println("j = "+j);
		}
	}

}
