package Threads;

public class ThreadUsingRunnableMain {

	public static void main(String[] args) {
		Thread3 th3=new Thread3();
		Thread4 th4=new Thread4();
		Thread t1=new Thread(th3);
		Thread t2=new Thread(th4);
		t1.start();
		t2.start();
	}

}
