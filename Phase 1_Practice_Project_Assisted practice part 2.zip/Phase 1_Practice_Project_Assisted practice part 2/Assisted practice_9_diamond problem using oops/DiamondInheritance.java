package OopsProperties;
interface Interface1{
	 void display(String a);
}
interface Interface2{
	void show(String b);
}

public class DiamondInheritance implements Interface1,Interface2{

	public void show(String b) {
		
		System.out.println(b);
	}
	public void display(String a) {
		System.out.println(a);
	}
	public static void main(String[] args) {
		DiamondInheritance d1=new DiamondInheritance();
		d1.display("You are in first Interface !\n");
		d1.show("You are in second Tnterface !");
	}

}
