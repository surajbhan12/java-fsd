package TryCatch;

public class LowBalanceException extends Exception {
	public LowBalanceException(String str) {
		super(str);
	}

}
