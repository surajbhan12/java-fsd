package TryCatch;
import java.util.*;
public class LowBalance {

	public void debit(int amount,int debitamount) throws LowBalanceException{
		if(amount<=debitamount) {
			throw new LowBalanceException("Low Balance!");
		}else {
			System.out.println("Remaining Balance = " +(amount-debitamount));
		}
	}
	public static void main(String args[]) {
		int amount=10000,debitamount;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Amount :-");
		debitamount=sc.nextInt();
		LowBalance lb=new LowBalance();
		try {
			lb.debit(amount,debitamount);
		}catch(Exception e){
			System.out.println("ERROR : "+e.getMessage());
		}
	}

}
