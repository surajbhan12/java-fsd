package FileHandling;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class FileDelete {
	public static void main(String[] args) throws IOException {
		String path="F:\\mphasis\\";
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the filename");
		String filename=sc.next();
		String finalpath=path+filename;
		File f=new File(finalpath);
		//delete operation
		f.delete();
		System.out.println("file gets deleted");
		
	}

}

