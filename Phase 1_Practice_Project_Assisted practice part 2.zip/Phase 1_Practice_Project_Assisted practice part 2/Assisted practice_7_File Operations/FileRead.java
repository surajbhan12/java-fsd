package FileHandling;

import java.io.*;
import java.util.Scanner;

public class FileRead {
	public static void main(String[] args) throws IOException {
		
		FileInputStream fi=new FileInputStream("input");
		if(fi!=null) {
			System.out.println("file exists");
		}
		else {
			System.out.println("File not exist ");
		}
		int i=0;
		//-1 is EOF
		while((i=fi.read())!=-1){
			System.out.print((char)i);
		}
	}
}

