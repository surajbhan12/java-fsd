package Threads;

public class Thread5 extends Thread {
	public void run() {
		for(int j=0;j<=10;j++)
		{
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("j = "+j);
		}
	}

}
