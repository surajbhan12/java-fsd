package Threads;

public class SleepAndWait {

	public static void main(String[] args) {
		Thread1 th5=new Thread1();
		Thread2 th6=new Thread2();
		th5.start();
		th6.start();

	}

}
