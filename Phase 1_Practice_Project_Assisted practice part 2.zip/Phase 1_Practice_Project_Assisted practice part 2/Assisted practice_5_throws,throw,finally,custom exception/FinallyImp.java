package TryCatch;

public class FinallyImp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=25,b=0,c=0;
		try {
			c=a/b;
		}catch(Exception e) {
			System.out.println("ERROR : "+e.getMessage());
		}
		finally {
				System.out.println("\nfinally must be Executed");
				System.out.println(c);
		}
	}

}
