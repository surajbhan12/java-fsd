package TryCatch;

public class ThrowImp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=25,b=0,c;
		try {
			if(b==0) {
				throw new Exception("can't divide by 0");
			}
			else {
				c=a/b;
				System.out.println(c);
			}
		}catch(Exception e) {
			System.out.println("ERROR : "+ e.getMessage());
		}

	}

}
