package TryCatch;

public class ThrowsImp {
	public void division() throws Exception {
		int a=25,b=0,c;
		c=a/b;
		System.out.println(c);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThrowsImp t1=new ThrowsImp();
		try {
			t1.division();
		}catch(Exception e) {
			System.out.println("ERROR : "+e.getMessage());
		}
	}

}
