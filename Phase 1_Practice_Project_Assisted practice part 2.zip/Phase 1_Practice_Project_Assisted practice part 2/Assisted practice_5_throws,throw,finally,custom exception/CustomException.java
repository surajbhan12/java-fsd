package TryCatch;

public class CustomException {
	public void validate(int age) throws InvalidAgeException{
		if(age<=18) {
			throw new InvalidAgeException("Age is not valid !");
		}else {
			System.out.println("Eligible for voting");
		}
	}
	public static void main(String args[]) {
		CustomException ce=new CustomException();
		try {
			ce.validate(15);
		}catch(Exception e){
			System.out.println("ERROR : "+e.getMessage());
		}
	}

}
