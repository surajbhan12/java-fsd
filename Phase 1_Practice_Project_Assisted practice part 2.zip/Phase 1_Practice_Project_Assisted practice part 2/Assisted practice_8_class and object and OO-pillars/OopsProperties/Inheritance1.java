package OopsProperties;

public class Inheritance1 {
	int a=200;
	}

