package OopsProperties;

public class EncapsulationImp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Encapsulation1 e1=new Encapsulation1(25,"Manish",30000);
		e1.display();
	}

}
