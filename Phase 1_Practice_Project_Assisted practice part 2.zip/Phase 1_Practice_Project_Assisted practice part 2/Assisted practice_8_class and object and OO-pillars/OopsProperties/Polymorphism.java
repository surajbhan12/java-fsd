package OopsProperties;

public class Polymorphism {
	//method overloading
	public void method() {
		System.out.println("you are in first method !\n");
	}
	public void method(int x) {
		System.out.println(x);
		System.out.println("you are in second method !\n");
	}
	public void method(int x,int y) {
		System.out.println(x+" "+y);
		System.out.println("you are in third method !");
	}
	public static void main(String[] args) {
		Polymorphism p1=new Polymorphism();
		p1.method();   //calling first method which has no argument.
		p1.method(5);  //calling method which has only one argument of integer type.
		p1.method(5,7);//calling method which has two argument of integer type.
	}
}
