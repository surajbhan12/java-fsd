package OopsProperties;

public class InheritanceImp extends Inheritance1{
	 int b=100+a;
	 public void display()
	 {
		 System.out.println(b);
	 }
	 public static void main(String[] args) {
		 InheritanceImp i1=new InheritanceImp();
		 i1.display();
	 }
}
