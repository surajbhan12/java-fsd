package OopsProperties;

public abstract class Abstract1 {
	public abstract int display(int a,int b);

}
