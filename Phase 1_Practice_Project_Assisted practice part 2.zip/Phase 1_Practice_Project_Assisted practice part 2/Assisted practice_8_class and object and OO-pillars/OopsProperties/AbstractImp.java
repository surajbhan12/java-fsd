package OopsProperties;

public class AbstractImp extends Abstract1 {

	public int display(int a, int b) {
		// TODO Auto-generated method stub
		
		return a + b;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractImp a1=new AbstractImp();
		System.out.println(a1.display(4, 6));
	}


}
