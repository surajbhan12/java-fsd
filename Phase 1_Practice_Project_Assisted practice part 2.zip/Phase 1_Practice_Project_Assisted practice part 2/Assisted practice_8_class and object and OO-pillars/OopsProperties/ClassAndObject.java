package OopsProperties;

public class ClassAndObject {
	public int sum(int a,int b) {
		return a+b;
	}
	public static void main(String[] args) {
		int a=10,b=20;
		ClassAndObject co=new ClassAndObject();
		System.out.println(co.sum(a, b));
	}

}
