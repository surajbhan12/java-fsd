

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class seleniumweb {
	public static void main(String[] args) throws InterruptedException {
		//register crome driver
		System.setProperty("webdriver.chrome.driver","D:\\95\\chromedriver.exe");
		WebDriver wd=new ChromeDriver();
		//maximize the screen
		wd.manage().window().maximize();
		//any website or any localhost
		wd.get("http://localhost:8083/");
		//System.out.println(wd.getCurrentUrl());
		//System.out.println(wd.getTitle());
		
		wd.findElement(By.name("email")).sendKeys("mani@123");
		wd.findElement(By.name("pwd")).sendKeys("mani@123");
		Thread.sleep(2000);
		wd.findElement(By.name("submit")).click();
		Thread.sleep(2000);
		wd.findElement(By.linkText("register here...")).click();
		wd.findElement(By.name("name")).sendKeys("manish");
		wd.findElement(By.name("email")).sendKeys("mani@123");
		wd.findElement(By.name("pwd")).sendKeys("mani@123");
		Thread.sleep(2000);
		wd.findElement(By.name("submit")).click();
		wd.findElement(By.name("email")).sendKeys("mani@123");
		wd.findElement(By.name("pwd")).sendKeys("mani@123");
		Thread.sleep(2000);
		wd.findElement(By.name("submit")).click();
		Thread.sleep(2000);

		
		//close the browser
		wd.close();
		
	}
}
