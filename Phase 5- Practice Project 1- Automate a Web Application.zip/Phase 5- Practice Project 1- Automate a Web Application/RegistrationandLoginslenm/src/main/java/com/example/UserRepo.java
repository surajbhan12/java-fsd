package com.example;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface UserRepo extends JpaRepository<User, String>{	
	@Query("select user from User user where user.email=?1")
	public User findByemail(String name);
	
	@Query("select user from User user where user.password=?1")
	public User findBypassword(String name);
}
