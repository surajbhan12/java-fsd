import java.sql.*;

public class StudentDAO {
	public int insert(Student s) throws ClassNotFoundException, SQLException {
		Connection con=DbUtil.getCon();
		if(con!=null) {
			System.out.println("connection is established");
		}
		else {
			System.out.println("connection failed");
		}
		
		Statement st=con.createStatement();
		String sql="insert into student values("+s.getSid()+","+"'"+s.getSname()+"'"+","+"'"+s.getSemail()+"')";
		//insert,update,delete->int value -no of rows
		int row=st.executeUpdate(sql);
		return row;// TODO Auto-generated method stub
	}
	public void retrieve() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con=DbUtil.getCon();
		if(con!=null) {
			System.out.println("connection is established");
		}
		else {
			System.out.println("connection failed");
		}
		Statement st=con.createStatement();
		String sql="select * from student";
		//select
		ResultSet rs=st.executeQuery(sql);
		
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3));
		}
	}
	public int update(Student s) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con=DbUtil.getCon();
		if(con!=null) {
			System.out.println("connection is established");
		}
		else {
			System.out.println("connection failed");
		}
		
		Statement st=con.createStatement();
		//insert,update,delete->int value -no of rows
		String sql="update student set sname='"+s.getSname()+"',semail='"+s.getSemail()+"' where sid="+s.getSid();
		int row=st.executeUpdate(sql);
		return row;//
	}
	public int delete(int id) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con=DbUtil.getCon();
		if(con!=null) {
			System.out.println("connection is established");
		}
		else {
			System.out.println("connection failed");
		}
		
		Statement st=con.createStatement();
		//insert,update,delete->int value -no of rows
		String sql="delete from student where sid="+id;
		int row=st.executeUpdate(sql);
		return row;
	}
}
