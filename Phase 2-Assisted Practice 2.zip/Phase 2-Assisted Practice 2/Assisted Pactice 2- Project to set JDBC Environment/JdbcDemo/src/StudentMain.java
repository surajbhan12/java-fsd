import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class StudentMain {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Student s=new Student();
		Scanner sc=new Scanner(System.in);
		Connection con=DbUtil.getCon();
		StudentDAO dao=new StudentDAO();
		int z;
		while(true) {
		System.out.println("1. Insertion\n2. Retriving\n3. Updation\n4. Deletion\n5. Exit");
		System.out.println("Choose Operation :-");
		z=sc.nextInt();
		switch(z) {
		case 1 : System.out.println("Enter Student ID -");
				s.setSid(sc.nextInt());
				System.out.println("Enter Student Name -");
				s.setSname(sc.next());
				System.out.println("Enter Student Email -");
				s.setSemail(sc.next());
				int i= dao.insert(s);
				if(i>0) {
					System.out.println("insertion done");
				}
				else {
					System.out.println("insertion failed");
				}
		break;
		case 2 :dao.retrieve();
		break;
		case 3 :System.out.println("Enter Student  ID for updation -");
				s.setSid(sc.nextInt());
				System.out.println("Enter new Student Name -");
				s.setSname(sc.next());
				System.out.println("Enter new Student Email -");
				s.setSemail(sc.next());
				int j=dao.update(s);
				if(j>0) {
					System.out.println("updation done");
				}
				else {
					System.out.println("updation failed");
				}
		break;
		case 4:System.out.println("Enter Student  ID for deletion -");
				int id=sc.nextInt();
				int k=dao.delete(id);
				if(k>0) {
					System.out.println("deletion done");
				}
				else {
					System.out.println("deletion failed");
				}
		break;
		case 5 : System.exit(0);
		break;
		default:
			System.out.println("Choose Correct Option !!!!!");
			break;
		}
		}

}
}
