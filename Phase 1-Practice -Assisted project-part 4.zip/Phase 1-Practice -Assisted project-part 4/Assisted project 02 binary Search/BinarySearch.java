package SearchingAndSorting;

import java.util.Arrays;
import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		int arr[]= {2,6,10,4,12,8,14,16};
		Arrays.sort(arr);
		System.out.println("After sorting array is :-");
		for(int j:arr) {
			System.out.print(j+" ");
		}
		System.out.println();
		Scanner sc=new Scanner(System.in);
		int start=0,end=arr.length-1,ele;
		int middle=(start+end)/2;
		System.out.println("Enter element to search :- ");
		ele=sc.nextInt();
		while(start<=end) {
			if(arr[middle]==ele) {
				System.out.println("Element found at index "+middle);
				break;
			}else if(ele<arr[middle]) {
				end=middle-1;
			}else {
				start=middle+1;
			}
			middle=(start+end)/2;
		}
		if(start>end) {
			System.out.println("Element not found");
		}
	}

}
