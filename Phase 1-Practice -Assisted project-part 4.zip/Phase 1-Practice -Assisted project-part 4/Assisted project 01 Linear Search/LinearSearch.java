package SearchingAndSorting;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		int arr[]= {7,5,2,9,6};
		int flag=0,i;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter number to search :- ");
        int n=sc.nextInt();
        for(i=0;i<arr.length;i++) {
        	if(arr[i]==n) {
        		flag=1;
        		break;
        	}
        }
        if(flag==1) {
        	System.out.println("Number found at index "+ i);
        }else {
        	System.out.println("Number not in the array !");
        }
	}

}
